package Client;

public class Main {
    public static void main(String[] args){
        ClientApplication mainFrame = new ClientApplication();  //Start the client application (the drawing thing)
        ClientPlugin plugin = new ClientPlugin();
    }    
}